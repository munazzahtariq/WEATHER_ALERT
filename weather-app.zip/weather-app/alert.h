#ifndef ALERT_H
#define ALERT_H

void send_alert(const char* alert_message);
void check_and_generate_alerts(int hour);  

#endif
